docker compose up
